#include "Train.hpp"



Train::Train()
{
}


Train::~Train()
{
}



