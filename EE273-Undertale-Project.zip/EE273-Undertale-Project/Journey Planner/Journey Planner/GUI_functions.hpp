#pragma once

#include<iostream>
#include"Destination.hpp"
#include<List>

bool inBox(std::list<Destination>*, sf::Vector2i, Destination*);
void OpenAddWindow();